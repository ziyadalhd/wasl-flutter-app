package com.example.Wasl.entity.enums;

public enum UserMode {
    STUDENT,
    PROVIDER
}
