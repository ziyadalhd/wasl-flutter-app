package com.example.Wasl.entity.enums;

public enum ProviderType {
    ACCOMMODATION,
    TRANSPORTATION,
    BOTH
}
