package com.example.Wasl.dto;

public interface ProfileDTO {
}
