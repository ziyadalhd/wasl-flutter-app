package com.example.Wasl.entity.enums;

public enum UserStatus {
    ACTIVE,
    SUSPENDED,
    DELETED
}
